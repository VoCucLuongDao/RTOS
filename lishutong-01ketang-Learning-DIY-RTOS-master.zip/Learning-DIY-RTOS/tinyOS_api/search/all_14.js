var searchData=
[
  ['计数信号量',['计数信号量',['../group___xE4_xBF_xA1_xE5_x8F_xB7_xE9_x87_x8F.html',1,'']]],
  ['软定时器',['软定时器',['../group___xE8_xBD_xAF_xE5_xAE_x9A_xE6_x97_xB6_xE5_x99_xA8.html',1,'']]]
];
