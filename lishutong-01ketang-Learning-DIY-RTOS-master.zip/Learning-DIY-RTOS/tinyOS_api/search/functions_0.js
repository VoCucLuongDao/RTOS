var searchData=
[
  ['idletaskentry',['idleTaskEntry',['../group___xE5_x86_x85_xE6_xA0_xB8_xE6_xA0_xB8_xE5_xBF_x83.html#ga1949c76c0bc7d4b976d447fbaa947f53',1,'tCore.c']]]
];
