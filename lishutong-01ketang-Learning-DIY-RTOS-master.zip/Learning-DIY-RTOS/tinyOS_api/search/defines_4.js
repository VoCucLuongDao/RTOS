var searchData=
[
  ['ticks_5fper_5fsec',['TICKS_PER_SEC',['../tiny_o_s_8h.html#a4a0c770328891d8916c1142a26481e4a',1,'tinyOS.h']]],
  ['tinyos_5ftask_5fstate_5fdelayed',['TINYOS_TASK_STATE_DELAYED',['../t_task_8h.html#a1a73506e326a6f9a58f3a07172c400a3',1,'tTask.h']]],
  ['tinyos_5ftask_5fstate_5fdestroyed',['TINYOS_TASK_STATE_DESTROYED',['../t_task_8h.html#a7e6e2156119d44e75177073ff1feb2fc',1,'tTask.h']]],
  ['tinyos_5ftask_5fstate_5frdy',['TINYOS_TASK_STATE_RDY',['../t_task_8h.html#ae9796d3f7bdb820b16b7ca53a44bcbd0',1,'tTask.h']]],
  ['tinyos_5ftask_5fstate_5fsuspend',['TINYOS_TASK_STATE_SUSPEND',['../t_task_8h.html#adec95d3273fe8be8c4018c9da38ebbc2',1,'tTask.h']]],
  ['tinyos_5ftask_5fwait_5fmask',['TINYOS_TASK_WAIT_MASK',['../t_task_8h.html#ab663c09edc989829da8ab2f037b99b11',1,'tTask.h']]],
  ['tnodeparent',['tNodeParent',['../t_lib_8h.html#a5a79804168bfcc4553dcf0a57d22724d',1,'tLib.h']]]
];
