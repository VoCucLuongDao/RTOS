var searchData=
[
  ['bitmap',['bitmap',['../structt_bitmap.html#adc5b4308ed7b0d1a073896de1d25636a',1,'tBitmap']]],
  ['blocklist',['blockList',['../struct__t_mem_block.html#a097b552e5270ca956f34af77c4b5aadf',1,'_tMemBlock']]],
  ['blocksize',['blockSize',['../struct__t_mem_block.html#ab6558f40a619c2502fbc24c880fd4fb0',1,'_tMemBlock::blockSize()'],['../struct__t_mem_block_info.html#ab6558f40a619c2502fbc24c880fd4fb0',1,'_tMemBlockInfo::blockSize()']]]
];
