var searchData=
[
  ['nvic_5fint_5fctrl',['NVIC_INT_CTRL',['../t_switch_8c.html#afa1ca44ad548bf5bfa2f19d7438c722a',1,'tSwitch.c']]],
  ['nvic_5fpendsv_5fpri',['NVIC_PENDSV_PRI',['../t_switch_8c.html#a3612aa5e26b7da530145fdddce3850ce',1,'tSwitch.c']]],
  ['nvic_5fpendsvset',['NVIC_PENDSVSET',['../t_switch_8c.html#a11166a59c430ba34e6da8e20571b58d7',1,'tSwitch.c']]],
  ['nvic_5fsyspri2',['NVIC_SYSPRI2',['../t_switch_8c.html#a23694ffa1ac38dfdfcc1ae1160be7397',1,'tSwitch.c']]]
];
