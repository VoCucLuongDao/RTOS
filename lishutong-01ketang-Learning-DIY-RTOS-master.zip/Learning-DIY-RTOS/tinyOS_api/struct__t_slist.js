var struct__t_slist =
[
    [ "firstNode", "struct__t_slist.html#a78f7ab83c83d0c6ce3aecdcf9a2f7908", null ],
    [ "lastNode", "struct__t_slist.html#a63a5ed558da6da47af7fd8b2ce027cad", null ],
    [ "nodeCount", "struct__t_slist.html#a9ff3c0ff509d8eb055d29faa0ec185a1", null ]
];