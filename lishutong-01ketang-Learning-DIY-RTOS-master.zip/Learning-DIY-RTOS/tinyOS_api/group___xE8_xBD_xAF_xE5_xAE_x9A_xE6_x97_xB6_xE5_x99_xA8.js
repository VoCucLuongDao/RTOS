var group___xE8_xBD_xAF_xE5_xAE_x9A_xE6_x97_xB6_xE5_x99_xA8 =
[
    [ "_tTimer", "struct__t_timer.html", [
      [ "arg", "struct__t_timer.html#a9ce2ec4812a92cb6ab39f6e81e9173a9", null ],
      [ "config", "struct__t_timer.html#ac0c635110dc503f164fff91b163936d7", null ],
      [ "delayTicks", "struct__t_timer.html#a0c1ef2b42e60232fd2355246df290c68", null ],
      [ "durationTicks", "struct__t_timer.html#a95f8cbd7a4ba89fc9ae542eb04a24bc0", null ],
      [ "linkNode", "struct__t_timer.html#ab9a5b93b6f7bf200c776df8731d99133", null ],
      [ "startDelayTicks", "struct__t_timer.html#acecf013811265c398517a464e7e6f7b2", null ],
      [ "state", "struct__t_timer.html#a1554a5dc790e401b90c319aad88f51dc", null ],
      [ "timerFunc", "struct__t_timer.html#a5b39f4308b8e715d9278cbf70f7297c7", null ]
    ] ],
    [ "_tTimerInfo", "struct__t_timer_info.html", [
      [ "arg", "struct__t_timer_info.html#a9ce2ec4812a92cb6ab39f6e81e9173a9", null ],
      [ "config", "struct__t_timer_info.html#ac0c635110dc503f164fff91b163936d7", null ],
      [ "durationTicks", "struct__t_timer_info.html#a95f8cbd7a4ba89fc9ae542eb04a24bc0", null ],
      [ "startDelayTicks", "struct__t_timer_info.html#acecf013811265c398517a464e7e6f7b2", null ],
      [ "state", "struct__t_timer_info.html#a1554a5dc790e401b90c319aad88f51dc", null ],
      [ "timerFunc", "struct__t_timer_info.html#a5b39f4308b8e715d9278cbf70f7297c7", null ]
    ] ],
    [ "TIMER_CONFIG_TYPE_HARD", "group___xE8_xBD_xAF_xE5_xAE_x9A_xE6_x97_xB6_xE5_x99_xA8.html#gadde5594113d4922dd2c044b7033e979c", null ],
    [ "TIMER_CONFIG_TYPE_SOFT", "group___xE8_xBD_xAF_xE5_xAE_x9A_xE6_x97_xB6_xE5_x99_xA8.html#gab47055541c84bda578ed3a9e913e4be2", null ],
    [ "tTimer", "group___xE8_xBD_xAF_xE5_xAE_x9A_xE6_x97_xB6_xE5_x99_xA8.html#gaef50316fbeedf44c30e1d837adf5f083", null ],
    [ "tTimerInfo", "group___xE8_xBD_xAF_xE5_xAE_x9A_xE6_x97_xB6_xE5_x99_xA8.html#ga087c2c7bcb3d8f05103cba1af9c58ea6", null ],
    [ "tTimerState", "group___xE8_xBD_xAF_xE5_xAE_x9A_xE6_x97_xB6_xE5_x99_xA8.html#ga61a3fc1d6f61d731f862d8925c97e184", null ],
    [ "_tTimerState", "group___xE8_xBD_xAF_xE5_xAE_x9A_xE6_x97_xB6_xE5_x99_xA8.html#ga5ae483b48ef1e10020eba42be4deb2ad", [
      [ "tTimerCreated", "group___xE8_xBD_xAF_xE5_xAE_x9A_xE6_x97_xB6_xE5_x99_xA8.html#gga5ae483b48ef1e10020eba42be4deb2ada5a03f072cc3183bc26038b39c73e97e0", null ],
      [ "tTimerStarted", "group___xE8_xBD_xAF_xE5_xAE_x9A_xE6_x97_xB6_xE5_x99_xA8.html#gga5ae483b48ef1e10020eba42be4deb2adaaf291cc8af972564c57c775a65c70fb5", null ],
      [ "tTimerRunning", "group___xE8_xBD_xAF_xE5_xAE_x9A_xE6_x97_xB6_xE5_x99_xA8.html#gga5ae483b48ef1e10020eba42be4deb2adabcc4ae59c2a81df941ffa3b3e367e95d", null ],
      [ "tTimerStopped", "group___xE8_xBD_xAF_xE5_xAE_x9A_xE6_x97_xB6_xE5_x99_xA8.html#gga5ae483b48ef1e10020eba42be4deb2ada8217513833783cfb2f446069d0bd5b56", null ],
      [ "tTimerDestroyed", "group___xE8_xBD_xAF_xE5_xAE_x9A_xE6_x97_xB6_xE5_x99_xA8.html#gga5ae483b48ef1e10020eba42be4deb2ada7c596d0db238155989a07e7f88a6182e", null ]
    ] ],
    [ "tTimerDestroy", "group___xE8_xBD_xAF_xE5_xAE_x9A_xE6_x97_xB6_xE5_x99_xA8.html#ga34c554ef3abd95f382165dae86122aef", null ],
    [ "tTimerGetInfo", "group___xE8_xBD_xAF_xE5_xAE_x9A_xE6_x97_xB6_xE5_x99_xA8.html#gade22d847f45a6140702a67ace6b34978", null ],
    [ "tTimerInit", "group___xE8_xBD_xAF_xE5_xAE_x9A_xE6_x97_xB6_xE5_x99_xA8.html#ga2a6a895916b16bcb9b01ac53cb28e015", null ],
    [ "tTimerInitTask", "group___xE8_xBD_xAF_xE5_xAE_x9A_xE6_x97_xB6_xE5_x99_xA8.html#ga6013a8ecf7fc98794f130d4bfb5f6402", null ],
    [ "tTimerModuleInit", "group___xE8_xBD_xAF_xE5_xAE_x9A_xE6_x97_xB6_xE5_x99_xA8.html#ga62301aa36a38ff645bdf05136b3fd6cf", null ],
    [ "tTimerModuleTickNotify", "group___xE8_xBD_xAF_xE5_xAE_x9A_xE6_x97_xB6_xE5_x99_xA8.html#gae4ae5ad72b29fa9cfcf5444de2d3be63", null ],
    [ "tTimerStart", "group___xE8_xBD_xAF_xE5_xAE_x9A_xE6_x97_xB6_xE5_x99_xA8.html#ga7a8932a1c16f4eb96e7a0620272d846e", null ],
    [ "tTimerStop", "group___xE8_xBD_xAF_xE5_xAE_x9A_xE6_x97_xB6_xE5_x99_xA8.html#ga7090133d856e1d8bfa5d619e7be397cb", null ]
];