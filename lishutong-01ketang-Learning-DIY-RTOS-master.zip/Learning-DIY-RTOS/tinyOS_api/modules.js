var modules =
[
    [ "位图结构", "group___xE4_xBD_x8D_xE5_x9B_xBE_xE7_xBB_x93_xE6_x9E_x84.html", "group___xE4_xBD_x8D_xE5_x9B_xBE_xE7_xBB_x93_xE6_x9E_x84" ],
    [ "内核核心", "group___xE5_x86_x85_xE6_xA0_xB8_xE6_xA0_xB8_xE5_xBF_x83.html", "group___xE5_x86_x85_xE6_xA0_xB8_xE6_xA0_xB8_xE5_xBF_x83" ],
    [ "事件控制块", "group___xE4_xBA_x8B_xE4_xBB_xB6_xE6_x8E_xA7_xE5_x88_xB6_xE5_x9D_x97.html", "group___xE4_xBA_x8B_xE4_xBB_xB6_xE6_x8E_xA7_xE5_x88_xB6_xE5_x9D_x97" ],
    [ "事件标志组", "group___xE4_xBA_x8B_xE4_xBB_xB6_xE6_xA0_x87_xE5_xBF_x97_xE7_xBB_x84.html", "group___xE4_xBA_x8B_xE4_xBB_xB6_xE6_xA0_x87_xE5_xBF_x97_xE7_xBB_x84" ],
    [ "Hooks扩展", "group___hooks_xE6_x89_xA9_xE5_xB1_x95.html", "group___hooks_xE6_x89_xA9_xE5_xB1_x95" ],
    [ "双向链表", "group___xE5_x8F_x8C_xE5_x90_x91_xE9_x93_xBE_xE8_xA1_xA8.html", "group___xE5_x8F_x8C_xE5_x90_x91_xE9_x93_xBE_xE8_xA1_xA8" ],
    [ "单向链表", "group___xE5_x8D_x95_xE5_x90_x91_xE9_x93_xBE_xE8_xA1_xA8.html", "group___xE5_x8D_x95_xE5_x90_x91_xE9_x93_xBE_xE8_xA1_xA8" ],
    [ "邮箱", "group___xE9_x82_xAE_xE7_xAE_xB1.html", "group___xE9_x82_xAE_xE7_xAE_xB1" ],
    [ "存储块", "group___xE5_xAD_x98_xE5_x82_xA8_xE5_x9D_x97.html", "group___xE5_xAD_x98_xE5_x82_xA8_xE5_x9D_x97" ],
    [ "互斥信号量", "group___xE4_xBA_x92_xE6_x96_xA5_xE4_xBF_xA1_xE5_x8F_xB7_xE9_x87_x8F.html", "group___xE4_xBA_x92_xE6_x96_xA5_xE4_xBF_xA1_xE5_x8F_xB7_xE9_x87_x8F" ],
    [ "计数信号量", "group___xE4_xBF_xA1_xE5_x8F_xB7_xE9_x87_x8F.html", "group___xE4_xBF_xA1_xE5_x8F_xB7_xE9_x87_x8F" ],
    [ "任务管理", "group___xE4_xBB_xBB_xE5_x8A_xA1_xE7_xAE_xA1_xE7_x90_x86.html", "group___xE4_xBB_xBB_xE5_x8A_xA1_xE7_xAE_xA1_xE7_x90_x86" ],
    [ "软定时器", "group___xE8_xBD_xAF_xE5_xAE_x9A_xE6_x97_xB6_xE5_x99_xA8.html", "group___xE8_xBD_xAF_xE5_xAE_x9A_xE6_x97_xB6_xE5_x99_xA8" ]
];