var struct__t_snode =
[
    [ "next", "struct__t_snode.html#acb9946bbe3ca53d8c93afb12fd030473", null ]
];