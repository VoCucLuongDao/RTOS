var struct__t_timer =
[
    [ "arg", "struct__t_timer.html#a9ce2ec4812a92cb6ab39f6e81e9173a9", null ],
    [ "config", "struct__t_timer.html#ac0c635110dc503f164fff91b163936d7", null ],
    [ "delayTicks", "struct__t_timer.html#a0c1ef2b42e60232fd2355246df290c68", null ],
    [ "durationTicks", "struct__t_timer.html#a95f8cbd7a4ba89fc9ae542eb04a24bc0", null ],
    [ "linkNode", "struct__t_timer.html#ab9a5b93b6f7bf200c776df8731d99133", null ],
    [ "startDelayTicks", "struct__t_timer.html#acecf013811265c398517a464e7e6f7b2", null ],
    [ "state", "struct__t_timer.html#a1554a5dc790e401b90c319aad88f51dc", null ],
    [ "timerFunc", "struct__t_timer.html#a5b39f4308b8e715d9278cbf70f7297c7", null ]
];