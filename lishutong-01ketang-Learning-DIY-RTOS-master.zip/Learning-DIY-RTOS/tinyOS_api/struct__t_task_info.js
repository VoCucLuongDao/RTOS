var struct__t_task_info =
[
    [ "delayTicks", "struct__t_task_info.html#a0c1ef2b42e60232fd2355246df290c68", null ],
    [ "prio", "struct__t_task_info.html#a6871573fefee3ad102e26a09e7a2f493", null ],
    [ "slice", "struct__t_task_info.html#a4fe7f19d35a11368d300b99348451fdd", null ],
    [ "stackFree", "struct__t_task_info.html#ab8b8202c533d50459f39dfab24e8873d", null ],
    [ "stackSize", "struct__t_task_info.html#ae20ace955faaa4fb797b69b75feef3d3", null ],
    [ "state", "struct__t_task_info.html#a1b0c7bd4d79798ef4e0ce23894c9aeb2", null ],
    [ "suspendCount", "struct__t_task_info.html#a70023864793bcef3ab18d4a66832ca6d", null ]
];