var t_task_8h =
[
    [ "TINYOS_TASK_STATE_DELAYED", "group___xE4_xBB_xBB_xE5_x8A_xA1_xE7_xAE_xA1_xE7_x90_x86.html#ga1a73506e326a6f9a58f3a07172c400a3", null ],
    [ "TINYOS_TASK_STATE_DESTROYED", "group___xE4_xBB_xBB_xE5_x8A_xA1_xE7_xAE_xA1_xE7_x90_x86.html#ga7e6e2156119d44e75177073ff1feb2fc", null ],
    [ "TINYOS_TASK_STATE_RDY", "group___xE4_xBB_xBB_xE5_x8A_xA1_xE7_xAE_xA1_xE7_x90_x86.html#gae9796d3f7bdb820b16b7ca53a44bcbd0", null ],
    [ "TINYOS_TASK_STATE_SUSPEND", "group___xE4_xBB_xBB_xE5_x8A_xA1_xE7_xAE_xA1_xE7_x90_x86.html#gadec95d3273fe8be8c4018c9da38ebbc2", null ],
    [ "TINYOS_TASK_WAIT_MASK", "group___xE4_xBB_xBB_xE5_x8A_xA1_xE7_xAE_xA1_xE7_x90_x86.html#gab663c09edc989829da8ab2f037b99b11", null ],
    [ "tTask", "group___xE4_xBB_xBB_xE5_x8A_xA1_xE7_xAE_xA1_xE7_x90_x86.html#ga6ea4613577781b54cedcdf93d8c829bd", null ],
    [ "tTaskInfo", "group___xE4_xBB_xBB_xE5_x8A_xA1_xE7_xAE_xA1_xE7_x90_x86.html#ga97ea5eb430cfe81fffcca7e1816cf5a3", null ],
    [ "tTaskStack", "group___xE4_xBB_xBB_xE5_x8A_xA1_xE7_xAE_xA1_xE7_x90_x86.html#gad85a7244ee07814c23914d3cfcc91412", null ],
    [ "tTaskDeleteSelf", "group___xE4_xBB_xBB_xE5_x8A_xA1_xE7_xAE_xA1_xE7_x90_x86.html#ga7e75a9fc2e7d9ca0bf62d519db50de00", null ],
    [ "tTaskForceDelete", "group___xE4_xBB_xBB_xE5_x8A_xA1_xE7_xAE_xA1_xE7_x90_x86.html#gad4f55f0276a954401641c0972f0020e3", null ],
    [ "tTaskGetInfo", "group___xE4_xBB_xBB_xE5_x8A_xA1_xE7_xAE_xA1_xE7_x90_x86.html#ga5713566b36243903f668bd8ecfd41f71", null ],
    [ "tTaskInit", "group___xE4_xBB_xBB_xE5_x8A_xA1_xE7_xAE_xA1_xE7_x90_x86.html#ga639ee038febea3c977d37585fcc8a573", null ],
    [ "tTaskIsRequestedDelete", "group___xE4_xBB_xBB_xE5_x8A_xA1_xE7_xAE_xA1_xE7_x90_x86.html#ga113466abdb6e224bd4da771809432819", null ],
    [ "tTaskRequestDelete", "group___xE4_xBB_xBB_xE5_x8A_xA1_xE7_xAE_xA1_xE7_x90_x86.html#ga0e06a0c4378977bc86236ac4e61ae10e", null ],
    [ "tTaskSetCleanCallFunc", "group___xE4_xBB_xBB_xE5_x8A_xA1_xE7_xAE_xA1_xE7_x90_x86.html#gae626b5c34d62e915c83dabcd77987ddd", null ],
    [ "tTaskSuspend", "group___xE4_xBB_xBB_xE5_x8A_xA1_xE7_xAE_xA1_xE7_x90_x86.html#ga9b1df557da8292af30d6ff42b48e0755", null ],
    [ "tTaskWakeUp", "group___xE4_xBB_xBB_xE5_x8A_xA1_xE7_xAE_xA1_xE7_x90_x86.html#gac08bc12c30a810c1ec5c48f330fd509a", null ]
];