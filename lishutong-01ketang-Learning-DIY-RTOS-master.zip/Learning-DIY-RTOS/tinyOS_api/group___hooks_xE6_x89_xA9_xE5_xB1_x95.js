var group___hooks_xE6_x89_xA9_xE5_xB1_x95 =
[
    [ "tHooksCpuIdle", "group___hooks_xE6_x89_xA9_xE5_xB1_x95.html#ga4c444a8e6a58c580a94955392f235dc3", null ],
    [ "tHooksSysTick", "group___hooks_xE6_x89_xA9_xE5_xB1_x95.html#ga4ecec95f33f3d06cd03c743bb3fbe3ce", null ],
    [ "tHooksTaskInit", "group___hooks_xE6_x89_xA9_xE5_xB1_x95.html#ga7c4f462bd1d7e22836519312218b8f1e", null ],
    [ "tHooksTaskSwitch", "group___hooks_xE6_x89_xA9_xE5_xB1_x95.html#gaf5f3298fd391c362d819f3a765834091", null ]
];