var t_mem_block_8c =
[
    [ "tMemBlockDestroy", "group___xE5_xAD_x98_xE5_x82_xA8_xE5_x9D_x97.html#gaee9913bc670870b17fa9dd86e125d1fe", null ],
    [ "tMemBlockGetInfo", "group___xE5_xAD_x98_xE5_x82_xA8_xE5_x9D_x97.html#gacb1cf37f4aa43734f48d3faee0883a13", null ],
    [ "tMemBlockInit", "group___xE5_xAD_x98_xE5_x82_xA8_xE5_x9D_x97.html#ga5af4d0c00dfeb923f7157c8f80692553", null ],
    [ "tMemBlockNotify", "group___xE5_xAD_x98_xE5_x82_xA8_xE5_x9D_x97.html#ga7d3a796b2adc7cae76cdc6dd4eadc3d6", null ],
    [ "tMemBlockNoWaitGet", "group___xE5_xAD_x98_xE5_x82_xA8_xE5_x9D_x97.html#gac5c449adc2d5137dad06af15945cb160", null ],
    [ "tMemBlockWait", "group___xE5_xAD_x98_xE5_x82_xA8_xE5_x9D_x97.html#ga1ffdf77b2ef5b1e59f0738c018747af5", null ]
];