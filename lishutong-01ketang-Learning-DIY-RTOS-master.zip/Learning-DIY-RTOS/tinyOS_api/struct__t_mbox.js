var struct__t_mbox =
[
    [ "count", "struct__t_mbox.html#a86988a65e0d3ece7990c032c159786d6", null ],
    [ "event", "struct__t_mbox.html#a8b516ab130f86e4b15ca025c98c3dc53", null ],
    [ "maxCount", "struct__t_mbox.html#a1cc8a4ba5eee24b560f9869012941e91", null ],
    [ "msgBuffer", "struct__t_mbox.html#a42b4bab76140c12b77b72ec381001c6c", null ],
    [ "read", "struct__t_mbox.html#a0a71cf941cf2509857d61e1443ad8eaa", null ],
    [ "write", "struct__t_mbox.html#ac4c9f9c5eac363cc22ecc18669cc3891", null ]
];