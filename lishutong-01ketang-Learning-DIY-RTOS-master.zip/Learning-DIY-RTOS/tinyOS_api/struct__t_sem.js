var struct__t_sem =
[
    [ "count", "struct__t_sem.html#a86988a65e0d3ece7990c032c159786d6", null ],
    [ "event", "struct__t_sem.html#a8b516ab130f86e4b15ca025c98c3dc53", null ],
    [ "maxCount", "struct__t_sem.html#a1cc8a4ba5eee24b560f9869012941e91", null ]
];