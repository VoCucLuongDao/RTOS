var struct__t_mutex =
[
    [ "event", "struct__t_mutex.html#a8b516ab130f86e4b15ca025c98c3dc53", null ],
    [ "lockedCount", "struct__t_mutex.html#a16598f387191bb413e5c802b23e501ef", null ],
    [ "owner", "struct__t_mutex.html#af99fea13bfba6d0a457c2779fa8ecc5a", null ],
    [ "ownerOriginalPrio", "struct__t_mutex.html#aa1d8803bb70576a417cba7092640ebd3", null ]
];